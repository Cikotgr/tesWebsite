let songs = [
    {
        name: 'Puisi Alam',
        path: '../musics/puisi-alam.mp3',
        artist: 'Fourtwnty',
        cover: '../musics/img/puisi alam.png'
    },
    {
        name: 'Kusut',
        path: '../musics/kusut.mp3',
        artist: 'Fourtwnty',
        cover: '../musics/img/kusut.png'
    },
    {
        name: 'Pilu Membiru',
        path: '../musics/pilu-membiru.mp3',
        artist: 'Kunto Aji',
        cover: '../musics/img/pilu membiru.png'
    },
    {
        name: 'Rehat',
        path: '../musics/rehat.mp3',
        artist: 'Kunto Aji',
        cover: '../musics/img/rehat.png'
    }
]